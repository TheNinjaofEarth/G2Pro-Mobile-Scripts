--光子竜降臨
function c100000495.initial_effect(c)
	aux.AddRitualProcGreater(c,aux.FilterBoolFunction(Card.IsCode,1045))
end
